require_relative 'open3'
require_relative 'keys'
require_relative 'gpg'