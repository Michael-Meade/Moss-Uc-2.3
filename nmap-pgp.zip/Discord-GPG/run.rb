# Require bot library
require_relative 'src/bot'
require_relative 'lib/utils.rb'